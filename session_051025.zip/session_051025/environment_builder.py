import random
import numpy as np
from math import pi
import swift
import spatialgeometry as geometry
from spatialgeometry import Cuboid
from spatialmath import SE3

class EnvironmentBuilder:
    def __init__(self):
        """Initialise Swift environment and load all objects."""
        self.env = swift.Swift()
        self.env.launch(realtime=True)
        self.env.set_camera_pose([3, 3, 2], [0, 0, 0])

        # Containers for later reference
        self.objects = []

        # Build static environment
        self._add_static_objects()

        # Add pick-and-place areas
        self._add_task_areas()

    # --------------------------------------------------------
    # Static objects (walls, tables, etc.)
    # --------------------------------------------------------
    def _add_static_objects(self):
        """Add all static geometry to the environment."""
        env = self.env
        g = geometry  # shorthand

        wall1 = g.Cuboid(pose=SE3(5.7, -0.1, 0) * SE3.Rz(-pi), color=[0.80, 0.78, 0.70, 1], scale=[0.255, 0.05, 0.052])
        wall2 = g.Cuboid(pose=SE3(0.8, 4.5, 0) * SE3.Rz(pi / 2), color=[0.7, 0.83, 0.75, 1], scale=[0.24, 0.05, 0.052])
        wall3 = g.Cuboid(pose=SE3(5.8, 9.3, 0), color=[0.7, 0.83, 0.75, 1], scale=[0.255, 0.05, 0.052])

        table = g.Cuboid(pose=SE3(2.5, 4.7, 0), color=[0.25, 0.25, 0.25, 1], scale=[2, 1, 1.0])
        table_3 = g.Cuboid(pose=SE3(3, 2, 0), color=[0.25, 0.25, 0.25, 1], scale=[0.001, 0.001, 0.0001])
        table2 = g.Cuboid(pose=SE3(5.5, -8, 0), color=[0.25, 0.25, 0.25, 1], scale=[0.007, 0.015, 0.0078])

        fence1 = g.Cuboid(pose=SE3(3.8, 0.15, 4.85) * SE3.Rx(pi / 2) * SE3.Ry(pi / 2),
                          color=[1.0, 0.55, 0.0, 1], scale=[0.0105, 0.01, 0.01])
        fence2 = g.Cuboid(pose=SE3(3.8, 2.6, 4.85) * SE3.Rx(pi / 2) * SE3.Ry(pi / 2),
                          color=[1.0, 0.55, 0.0, 1], scale=[0.0105, 0.01, 0.01])
        fence3 = g.Cuboid(pose=SE3(3.8, 6, 4.85) * SE3.Rx(pi / 2) * SE3.Ry(pi / 2),
                          color=[1.0, 0.55, 0.0, 1], scale=[0.013, 0.01, 0.01])

        saftey_button1 = g.Cuboid(pose=SE3(6.5, 0.2, 1.5) * SE3.Rz(-pi) * SE3.Rx(pi / 2),
                                  color=[0.55, 0.0, 0.0, 1], scale=[0.004, 0.004, 0.002])
        saftey_button2 = g.Cuboid(pose=SE3(6.5, 0.2, 1.5) * SE3.Rz(-pi) * SE3.Rx(pi / 2),
                                  color=[0.7, 0.55, 0.0, 1], scale=[0.004, 0.004, 0.002])

        floor = Cuboid(scale=[10.3, 9.65, 0.01], color=[0.78, 0.86, 0.73, 1])
        floor.T = SE3(5.8, 4.6, 0)
        Workingzone = Cuboid(scale=[3.2, 9.5, 0.02], color=[0.78, 0.086, 0.073, 0.5])
        Workingzone.T = SE3(2.2, 4.5, 0)

        plate = g.Cuboid(pose=SE3(2, 7.2, 0), color=(0.76, 0.60, 0.42), scale=[2, 1, 1])
        plate2 = g.Cuboid(pose=SE3(2, 8.5, 0), color=(0.76, 0.60, 0.42), scale=[2, 1, 1])
        fan = g.Cuboid(pose=SE3(1, 2, 4.5) * SE3.Rx(pi / 2) * SE3.Ry(pi / 2) * SE3.Rz(pi),
                       color=(0.50, 0.42, 0.35), scale=[0.05, 0.05, 0.01])

        window_wall = g.Cuboid(pose=SE3(5.8, 0.1, 0) * SE3.Rz(pi / 2),
                               color=(0.75, 0.75, 0.8), scale=[0.01, 0.15, 0.015])
        control1 = g.Cuboid(pose=SE3(5, 0.15, 1.1) * SE3.Rz(pi / 2),
                            color=(0.5, 0.8, 1.0, 0.4), scale=[0.02, 0.02, 0.01])
        control2 = g.Cuboid(pose=SE3(5, 0.1, 1.1) * SE3.Rz(pi / 2),
                            color=(0.3, 0.3, 0.5, 0.8), scale=[0.03, 0.03, 0.01])
        window1 = g.Cuboid(pose=SE3(3, 0.15, 2) * SE3.Rz(pi / 2),
                           color=(0.5, 0.8, 0.9), scale=[0.01, 0.03, 0.03])
        window2 = g.Cuboid(pose=SE3(7, 0.15, 2) * SE3.Rz(pi / 2),
                           color=(0.5, 0.8, 0.9), scale=[0.01, 0.03, 0.03])

        shutter = g.Cuboid(pose=SE3(1, 8, 0) * SE3.Rx(pi / 2) * SE3.Ry(pi / 2),
                           color=(0.3, 0.3, 0.32, 0.9), scale=[0.0015, 0.0015, 0.0015])

        # Lights
        light1 = g.Cuboid(pose=SE3(1, 2, 4), color=(0.65, 0.67, 0.7), scale=[0.006, 0.006, 0.006])
        light2 = g.Cuboid(pose=SE3(3, 2, 4), color=(0.65, 0.67, 0.7), scale=[0.006, 0.006, 0.006])

        for obj in [wall1, wall2, wall3, table, table_3, table2,
                    fence1, fence2, fence3, saftey_button1, saftey_button2,
                    floor, Workingzone, plate, plate2, fan,
                    window_wall, control1, control2, window1, window2,
                    shutter, light1, light2]:
            env.add(obj)
            self.objects.append(obj)

    # --------------------------------------------------------
    # Trash objects (randomly scattered)
    # --------------------------------------------------------
 

    # --------------------------------------------------------
    # Task areas (pick zone, bin zone)
    # --------------------------------------------------------
    def _add_task_areas(self):
        """Add work areas for pick and place."""
        self.area = Cuboid(scale=[0.5, 0.5, 0.01], color=[1, 0.6, 0, 1])
        self.area.T = SE3(3.3, 5.7, 0.2)

        self.area_box = Cuboid(scale=[0.3, 0.3, 0.01], color=[0.5, 0.6, 0, 1])
        self.area_box.T = SE3(2.5, 5.5, 0.05)

        self.env.add(self.area)
        self.env.add(self.area_box)
