import os
from math import pi
import roboticstoolbox as rtb
import spatialmath.base as spb
from spatialgeometry import Cylinder
from ir_support.robots.DHRobot3D import DHRobot3D



class Gen3Lite(DHRobot3D):
    def __init__(self, scale=1.5):
        """
        Kinova Gen3 Lite Robot using DH parameters and STL visualization
        scale: 模型放大倍數 (預設 1.5)
        """
        self.scale = scale

        # DH links
        links = self._create_DH()

        # STL link names
        link3D_names = dict(
            link0='base_link',
            link1='shoulder_link',
            link2='arm7',
            link3='fm3',
            link4='lower_wrist',
            link5='upper_wrist',
            link6='base_link'   # ⚠️ 這個會被透明小球覆蓋
        )

        # 測試姿態 (qtest)
        qtest = [0, 0, 0, 0, 0, 0]
        s = self.scale   # 縮放倍數
        qtest_transforms = [
            spb.transl(0, 0, -0.112 * s),      
            spb.transl(0, 0, 0.013 * s),       
            spb.transl(0, -0.02 * s, 0.128 * s),   
            spb.transl(0, -0.0205 * s, 0.408 * s), 
            spb.transl(0.138 * s, 0, 0.408 * s),   
            spb.transl(0.2428 * s, 0, 0.38 * s),   
            spb.transl(0.39 * s, 0, 0.35 * s) @ spb.rpy2tr(0, pi/2, 0, order='xyz')
        ]

        current_path = os.path.abspath(os.path.dirname(__file__))
        super().__init__(links, link3D_names, name='Gen3Lite',
                         link3d_dir=current_path,
                         qtest=qtest, qtest_transforms=qtest_transforms)

        # 顏色設定
        colors = [
            (0.45, 0.42, 0.40, 1),   
            (0.55, 0.55, 0.55, 1),   
            (0.45, 0.42, 0.40, 1),   
            (0.45, 0.42, 0.40, 1),   
            (0.45, 0.42, 0.40, 0.8), 
            (0.55, 0.55, 0.55, 0.9), 
            (0.55, 0.55, 0.55, 1)    
        ]
        for i, mesh in enumerate(self.links_3d):
            mesh.color = tuple(float(c) for c in colors[i])
            mesh.scale = [s, s, s]   # ⚡ Mesh 放大

        # dummy end-effector
        dummy_ee = Cylinder(
            radius=0.03 * s,     # 半徑隨比例縮放
            length=0.02 * s,     # 高度隨比例縮放
            color=(0.45, 0.30, 0.20, 0.5),
        )
        self.links_3d[-1] = dummy_ee

        self.q = qtest

    # -----------------------------------------------------------------------------------#
    def _create_DH(self):
        """
        Create DH model for Gen3 Lite (from URDF approx)
        """
        s = self.scale
        a = [0, 0.28 * s, 0, 0, 0, 0]
        d = [0.128 * s, 0, 0, 0.2428 * s, -0.055 * s, 0.15 * s]
        alpha = [pi/2, 0, pi/2, pi/2, -pi/2, 0]
        offset = [0, pi/2, 0, pi/2, 0, 0]

        qlim = [
            [-2.7, 2.7],
            [-2.7, 2.7],
            [-2.7, 2.7],
            [-2.6, 2.6],
            [-2.6, 2.6],
            [-2.6, 2.6]
        ]

        links = []
        for i in range(6):
            link = rtb.RevoluteDH(
                d=float(d[i]), a=float(a[i]),
                alpha=float(alpha[i]),
                offset=float(offset[i]),
                qlim=[float(qlim[i][0]), float(qlim[i][1])]
            )
            links.append(link)
        return links

