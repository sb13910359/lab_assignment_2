# gui_controller.py
import time
import numpy as np
import swift
import roboticstoolbox as rtb
from spatialmath import SE3


class RobotGUI:
    """
    GUI controller for Swift-based robot simulation.
    Provides sliders for joint and Cartesian control,
    as well as mode and e-stop management.
    """

    def __init__(self, env, robot, gripper_fn, base_fn, target_ball=None):
        """
        Parameters
        ----------
        env : swift.Swift
            The Swift environment instance.
        robot : rtb.DHRobot
            The robot model to control.
        gripper_fn : function
            Function to visually update gripper placement.
        base_fn : function
            Function to visually update robot base placement.
        target_ball : optional geometry object
            Object being held (if any).
        """
        self.env = env
        self.robot = robot
        self.gripper_stick_arm = gripper_fn
        self.robot_stick_base = base_fn
        self.target_ball = target_ball

        # State variables (shared with global simulation)
        self.mode = "patrol"
        self.e_stop = False
        self.holding = False
        self.pick_and_place = False

        # Initialize GUI elements
        self._setup_buttons()
        self._setup_sliders()

    # --------------------------------------------------
    # Joint control callback (更新關節角度)
    # --------------------------------------------------
    def _slider_callback(self, value_deg, joint_index):
        """Called when a joint slider is moved."""
        if self.mode == "patrol" or self.e_stop:
            return

        q = self.robot.q.copy()
        q[joint_index] = np.deg2rad(float(value_deg))
        self.robot.q = q

        # If holding an object, move it with the end effector
        if self.holding and self.target_ball is not None:
            self.target_ball.T = self.robot.fkine(self.robot.q) * SE3(0, 0, 0.06)

        # Update visualization
        self.gripper_stick_arm()
        self.robot_stick_base()
        self.env.step(0.02)

    # --------------------------------------------------
    # Cartesian control callback (更新末端位置)
    # --------------------------------------------------
    def _cartesian_callback(self, delta, axis):
        """Jog the end-effector in Cartesian space by delta along the given axis."""
        if self.mode == "patrol" or self.e_stop:
            return

        T = self.robot.fkine(self.robot.q)
        if axis == "x":
            T_new = T * SE3(delta, 0, 0)
        elif axis == "y":
            T_new = T * SE3(0, delta, 0)
        elif axis == "z":
            T_new = T * SE3(0, 0, delta)
        else:
            return

        q_new = self.robot.ikine_LM(T_new, q0=self.robot.q).q
        q_traj = rtb.jtraj(self.robot.q, q_new, 50).q

        for q in q_traj:
            self.robot.q = q
            self.gripper_stick_arm()
            self.robot_stick_base()
            self.env.step(0.02)
            time.sleep(0.02)

            if self.holding and self.target_ball is not None:
                self.target_ball.T = self.robot.fkine(self.robot.q) * SE3(0, 0, 0.06)

        self.gripper_stick_arm()
        self.robot_stick_base()
        self.env.step(0.02)

    # --------------------------------------------------
    # GUI setup
    # --------------------------------------------------
    def _setup_buttons(self):
        """Create mode and E-Stop buttons in the GUI."""
        self.manual_btn = swift.Button(
            desc="Manual Mode",
            cb=lambda _=None: self._set_mode("manual")
        )
        self.patrol_btn = swift.Button(
            desc="Patrol Mode",
            cb=lambda _=None: self._set_mode("patrol")
        )
        self.estop_btn = swift.Button(
            desc="-- E-STOP --",
            cb=lambda _=None: self._trigger_estop()
        )
        self.resume_btn = swift.Button(
            desc="-- Resume --",
            cb=lambda _=None: self._resume_from_estop()
        )

        self.env.add(self.manual_btn)
        self.env.add(self.patrol_btn)
        self.env.add(self.estop_btn)
        self.env.add(self.resume_btn)

    def _setup_sliders(self):
        """Create joint and Cartesian sliders in the GUI."""
        # Joint sliders
        for i in range(self.robot.n):
            s = swift.Slider(
                cb=lambda v, j=i: self._slider_callback(v, j),
                min=-180, max=180, step=1,
                value=np.rad2deg(self.robot.q[i]),
                desc=f"Joint {i+1}",
                unit="°"
            )
            self.env.add(s)

        # Cartesian sliders
        self.env.add(swift.Slider(
            cb=lambda v: self._cartesian_callback(v * 0.01, "x"),
            min=-10, max=10, step=1, value=0,
            desc="ΔX", unit="cm"
        ))
        self.env.add(swift.Slider(
            cb=lambda v: self._cartesian_callback(v * 0.01, "y"),
            min=-10, max=10, step=1, value=0,
            desc="ΔY", unit="cm"
        ))
        self.env.add(swift.Slider(
            cb=lambda v: self._cartesian_callback(v * 0.01, "z"),
            min=-10, max=10, step=1, value=0,
            desc="ΔZ", unit="cm"
        ))

    # --------------------------------------------------
    # Helper methods
    # --------------------------------------------------
    def _set_mode(self, mode):
        """Switch between manual and patrol modes."""
        self.mode = mode
        self.pick_and_place = False
        print(f"✅ Mode set to: {self.mode}")

    def _trigger_estop(self):
        """Trigger emergency stop."""
        self.e_stop = True
        print("🚨 E-STOP activated!")

    def _resume_from_estop(self):
        """Allow system to be resumed (not auto-resumed)."""
        if not self.e_stop:
            print("⚠️ System already running.")
        else:
            self.e_stop = False
            print("✅ E-STOP disengaged. Manual resume required.")
